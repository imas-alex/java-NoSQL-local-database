import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;
import gdt.data.entity.EntityHandler;
import gdt.data.grain.Core;
import gdt.data.grain.Locator;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.base.JBaseNavigator;
import gdt.jgui.console.JConsoleHandler;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.JEntityPrimaryMenu;
import gdt.jgui.entity.index.JIndexPanel;
import gdt.jgui.entity.procedure.JProcedurePanel;
import gdt.jgui.entity.procedure.Procedure;
import java.util.ArrayList;
import java.util.Collections;
public class _TSYjrjLJjSnvPkDyk0_StLkzm1Vc  implements Procedure {
private final static String ENTITY_KEY="_TSYjrjLJjSnvPkDyk0_StLkzm1Vc";
@Override
public void run(JMainConsole console,String entihome$,Integer dividerLocation){
try{
//Do NOT change this section of the code
Entigrator entigrator=console.getEntigrator(entihome$);
String label$=entigrator.indx_getLabel(ENTITY_KEY);
// Put procedure code here
String home$=entigrator.ent_getHome(ENTITY_KEY);
String file$=home$+"/Favorites.tar";
JBaseNavigator.insertEntities(console, entihome$, file$);		
//Do NOT change this section of the code
File report=new File(entihome$+"/"+ENTITY_KEY+"/report.txt");
if(!report.exists())
	report.createNewFile();
Date curDate = new Date();
SimpleDateFormat format = new SimpleDateFormat();
format = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
String date$= format.format(curDate);
FileOutputStream fos = new FileOutputStream(report, false);
Writer writer = new OutputStreamWriter(fos, "UTF-8");
writer.write("Report:   "+label$+"\n");
writer.write(date$+"\n");
writer.write("__________ Restore _____________\n");
//Put report code here

//Do NOT change this section of the code
writer.close();
JProcedurePanel jpp=new JProcedurePanel();
String jppLocator$=jpp.getLocator();
jppLocator$=Locator.append(jppLocator$, Entigrator.ENTIHOME, entihome$);
jppLocator$=Locator.append(jppLocator$, EntityHandler.ENTITY_KEY,ENTITY_KEY);
jppLocator$=Locator.append(jppLocator$, JProcedurePanel.DIVIDER_LOCATION,String.valueOf(dividerLocation));
JConsoleHandler.execute(console, jppLocator$);
}catch(Exception e){
Logger.getLogger(getClass().getName());
}
}
}
