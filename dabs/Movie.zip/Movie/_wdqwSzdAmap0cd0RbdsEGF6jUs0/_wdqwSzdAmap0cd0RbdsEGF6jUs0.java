import java.util.ArrayList;
import java.util.logging.Logger;
import gdt.data.store.Entigrator;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.query.Query;
public class _wdqwSzdAmap0cd0RbdsEGF6jUs0  implements Query {
private final static String ENTITY_KEY="_wdqwSzdAmap0cd0RbdsEGF6jUs0";
@Override
public String[] select(Entigrator entigrator){
try{
//Do NOT change this section of the code

String [] sa;
// Put query code here
String[] na=entigrator.indx_listEntities("noactor","true");
ArrayList<String>sl=new ArrayList<String>();
sa=entigrator.indx_listEntities("entity","person");
boolean skip;
for(String s:sa){
	skip=false;
	for(String n:na)
		if(s.equals(n)){
			skip=true;
			break;
		}
	if(!skip)
		sl.add(s);
}
	
//
//Do NOT change this section of the code
return sl.toArray(new String[0]);
}catch(Exception e){
Logger.getLogger(getClass().getName());
return null;
}
}
}
