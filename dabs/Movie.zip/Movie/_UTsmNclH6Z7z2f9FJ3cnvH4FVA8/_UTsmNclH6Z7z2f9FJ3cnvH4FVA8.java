import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;
import gdt.data.entity.EntityHandler;
import gdt.data.grain.Core;
import gdt.data.grain.Locator;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.console.JConsoleHandler;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.procedure.JProcedurePanel;
import gdt.jgui.entity.procedure.Procedure;
import java.util.ArrayList;
import java.util.Collections;
public class _UTsmNclH6Z7z2f9FJ3cnvH4FVA8  implements Procedure {
private final static String ENTITY_KEY="_UTsmNclH6Z7z2f9FJ3cnvH4FVA8";
@Override
public void run(JMainConsole console,String entihome$,Integer dividerLocation){
try{
//Do NOT change this section of the code
Entigrator entigrator=console.getEntigrator(entihome$);
String label$=entigrator.indx_getLabel(ENTITY_KEY);
// Put procedure code here
String edgeKey$=entigrator.indx_keyAtLabel("ACTED_IN");
Sack edge=entigrator.getEntityAtKey(edgeKey$); 
Core[] ca=edge.elementGet("detail");
ArrayList<String>sl=new ArrayList<String>();
Sack detail; 
Core bond;
 for(Core c:ca){
	 detail=entigrator.getEntityAtKey(c.value);
	 if(detail==null)
		 continue;
	 bond=edge.getElementItem("bond", c.type);
	 if(bond==null)
		 continue;
	 if(!detail.existsElement("bond"))
	    	detail.createElement("bond");
	    if(!detail.existsElement("edge"))
	    	detail.createElement("edge");
	    detail.putElementItem("bond", bond);
	    detail.putElementItem("edge", new Core(null,c.type,edgeKey$));
		detail.putElementItem("fhandler",new Core(null, "gdt.data.entity.BondDetailHandler","_Tm142C8Sgti2iAKlDEcEXT2Kj1E"));
        entigrator.replace(detail);
		sl.add(detail.getProperty("label"));
 }
 Collections.sort(sl);
//
//Do NOT change this section of the code
File report=new File(entihome$+"/"+ENTITY_KEY+"/report.txt");
if(!report.exists())
	report.createNewFile();
Date curDate = new Date();
SimpleDateFormat format = new SimpleDateFormat();
format = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
String date$= format.format(curDate);
FileOutputStream fos = new FileOutputStream(report, false);
Writer writer = new OutputStreamWriter(fos, "UTF-8");
writer.write("Report:   "+label$+"\n");
writer.write(date$+"\n");
writer.write("__________ All entities _____________\n");
//Put report code here
for(String s:sl)
	writer.write(s+"\n");
//Do NOT change this section of the code
writer.close();
JProcedurePanel jpp=new JProcedurePanel();
String jppLocator$=jpp.getLocator();
jppLocator$=Locator.append(jppLocator$, Entigrator.ENTIHOME, entihome$);
jppLocator$=Locator.append(jppLocator$, EntityHandler.ENTITY_KEY,ENTITY_KEY);
jppLocator$=Locator.append(jppLocator$, JProcedurePanel.DIVIDER_LOCATION,String.valueOf(dividerLocation));
JConsoleHandler.execute(console, jppLocator$);
}catch(Exception e){
Logger.getLogger(getClass().getName());
}
}
}
