import java.sql.Timestamp;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.logging.Logger;

import javax.swing.table.DefaultTableModel;

import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.entity.view.DateHandler;
import gdt.jgui.entity.view.View;
public class _TqT3xf5Y_kIjz_SpY5rk33hG_grY  implements View {
private final static String ENTITY_KEY="_TqT3xf5Y_kIjz_SpY5rk33hG_grY";
//Sales by category
@Override
public DefaultTableModel select(Entigrator entigrator) {
	Timestamp begin=DateHandler.getTimestamp("1997-01-01T00:00:00",null);
	Timestamp end=DateHandler.getTimestamp("1997-12-31T00:00:00",null);
	String[] soa=entigrator.indx_listEntities("entity", "nwOrder");
	
	Sack id2key=entigrator.getEntityAtKey(entigrator.indx_keyAtLabel("id2key"));
	String orderDate$;
	Sack orderDetail;
	String unitPrice$;
	String quantity$;
	String discount$;
	String productId$;
	String productKey$;
	String productName$;
	Sack product;
	String categoryId$;
	String categoryKey$;
	String categoryName$;
	Sack category;
	
	Hashtable<String,Float> productSales=new Hashtable<String,Float>(); 
	Hashtable<String,String> categoryNames=new Hashtable<String,String>(); 
	Hashtable<String,String> categoryIDs=new Hashtable<String,String>(); 
	Sack order;
	DefaultTableModel model=new DefaultTableModel();
	model.setColumnIdentifiers(new String[]{"num",
			"CategoryID"
			,"CategoryName"
			,"ProductName"
			,"ProductSales"
			});
	int num=1;
	String[] sda;
	float detailAmount;
	Float productAmount;
	System.out.println("_TqT3xf5Y_kIjz_SpY5rk33hG_grY:select:soa="+soa.length);
	for(String s:soa){
		try{
		order=entigrator.getEntityAtKey(s);
		orderDate$=order.getElementItemAt("field", "OrderDate");
		if(!DateHandler.between(orderDate$, begin, end, null))
			continue;
	    sda=entigrator.ent_listComponents(order);
	    if(sda!=null)
	    	for(String d:sda){
	    		try{
	    		orderDetail=entigrator.getEntityAtKey(d);
	    		if("nwOrderDetail".equals(orderDetail.getProperty("entity"))){
	    			System.out.println("_TqT3xf5Y_kIjz_SpY5rk33hG_grY:orderDetail="+orderDetail.getProperty("label"));
	    			unitPrice$=orderDetail.getElementItemAt("field", "UnitPrice");
	    			quantity$=orderDetail.getElementItemAt("field", "Quantity");
	    			discount$=orderDetail.getElementItemAt("field", "Discount");
	    			detailAmount=Float.parseFloat(unitPrice$)*Float.parseFloat(quantity$)*(1-Float.parseFloat(discount$));
	    			 System.out.println("_TqT3xf5Y_kIjz_SpY5rk33hG_grY:detailAmount="+detailAmount);
	    			productId$=orderDetail.getElementItemAt("field", "ProductID");
	    		    productKey$=id2key.getElementItemAt("ProductID", productId$);
	    		    product=entigrator.getEntityAtKey(productKey$);
	    		    productName$=product.getElementItemAt("field", "ProductName");
	    		    categoryId$=product.getElementItemAt("field", "CategoryID");
	    		    categoryKey$=id2key.getElementItemAt("CategoryID", categoryId$);
	    		    category=entigrator.getEntityAtKey(categoryKey$);
	    		    categoryName$=category.getElementItemAt("field", "CategoryName");
	                categoryNames.put(productName$, categoryName$);
	                categoryIDs.put(productName$, categoryId$);
	                if(productSales.get(productName$)==null)
	                	productAmount=new Float(0);
	                else
	                	productAmount=productSales.get(productName$);
	                System.out.println("_TqT3xf5Y_kIjz_SpY5rk33hG_grY:productAmount="+productAmount);
	                productSales.put(productName$, new Float(productAmount.floatValue()+detailAmount));
	    		}
	    	}catch(Exception ee){
	    		Logger.getLogger(getClass().getName()).info(ee.toString());
	    	}
	    		entigrator.clearCache();
	    	}
		}catch(Exception e){
	    	Logger.getLogger(getClass().getName()).info(e.toString());
	    }
	}
	Enumeration<String> productNames=productSales.keys();
	while(productNames.hasMoreElements()){
		productName$=productNames.nextElement();
		categoryId$=categoryIDs.get(productName$);
		categoryName$=categoryNames.get(productName$);
		productAmount=productSales.get(productName$);
		model.addRow(new String[]{String.valueOf(num++)
				,categoryId$
				,categoryName$
				,productName$
				,String.valueOf(productAmount)
});
	}
	
	return model;
}
@Override
public String getColumnType(String columnName$) {
	if("num".equals(columnName$))
    	return "int";
	if("CategoryID".equals(columnName$))
    	return "int";
    if("ProductSales".equals(columnName$))
    	return "float";
    return "String";
}
}
