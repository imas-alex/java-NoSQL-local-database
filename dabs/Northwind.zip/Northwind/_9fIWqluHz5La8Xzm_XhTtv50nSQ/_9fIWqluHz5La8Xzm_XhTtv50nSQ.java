import java.util.logging.Logger;

import gdt.data.grain.Core;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;


import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;
import gdt.data.entity.EntityHandler;
import gdt.data.grain.Locator;
import gdt.jgui.console.JConsoleHandler;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.procedure.JProcedurePanel;
import gdt.jgui.entity.procedure.Procedure;
public class _9fIWqluHz5La8Xzm_XhTtv50nSQ  implements Procedure {
private final static String ENTITY_KEY="_9fIWqluHz5La8Xzm_XhTtv50nSQ";
@Override
public void run(JMainConsole console,String entihome$,Integer dividerLocation){
try{
	 Entigrator entigrator=console.getEntigrator(entihome$);
	 String[] sa=entigrator.indx_listEntities("entity", "nwOrderDetail");
	 //System.out.println("Add order ID:sa="+sa.length);
	 Sack orderDetail;
	 Sack order;
	 String[] ca;
	 String orderId$;
	 for(String s:sa){
		try{
		 //System.out.println("Add order ID:order key="+s); 
	 	orderDetail=entigrator.getEntityAtKey(s);
	 	if(orderDetail==null){
	 		System.out.println("Add order ID:cannot get order");
	 		continue;
	 	}
	 	ca=entigrator.ent_listContainers(orderDetail);
	 	if(ca==null){
	 		System.out.println("Add order ID:cannot get containers");
	 		continue;
	 	}
	 	//System.out.println("Add order ID:ca="+ca.length);
	 	order=entigrator.getEntityAtKey(ca[0]);
	 	orderId$=order.getElementItemAt("field", "OrderID");
	 	// System.out.println("Add order ID:order ID="+orderId$);
	 	orderDetail.putElementItem("field", new Core(null,"OrderID",orderId$));
	 	entigrator.replace(orderDetail);
		}catch(Exception ee){
			 System.out.println("Add order ID:"+ee.toString());
		}
	 }
//
//Do NOT change this section of the code
File report=new File(entihome$+"/"+ENTITY_KEY+"/report.txt");
if(!report.exists())
	report.createNewFile();
Date curDate = new Date();
SimpleDateFormat format = new SimpleDateFormat();
format = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
String date$= format.format(curDate);
FileOutputStream fos = new FileOutputStream(report, false);
Writer writer = new OutputStreamWriter(fos, "UTF-8");
writer.write("Report:   Done\n");
writer.write(date$+"\n");

//Do NOT change this section of the code
writer.close();
JProcedurePanel jpp=new JProcedurePanel();
String jppLocator$=jpp.getLocator();
jppLocator$=Locator.append(jppLocator$, Entigrator.ENTIHOME, entihome$);
jppLocator$=Locator.append(jppLocator$, EntityHandler.ENTITY_KEY,ENTITY_KEY);
jppLocator$=Locator.append(jppLocator$, JProcedurePanel.DIVIDER_LOCATION,String.valueOf(dividerLocation));
JConsoleHandler.execute(console, jppLocator$);
}catch(Exception e){
Logger.getLogger(getClass().getName());
}
}
@Override
public void run(Entigrator entigrator, Integer dividerLocation) {
	// TODO Auto-generated method stub
	
}
}
