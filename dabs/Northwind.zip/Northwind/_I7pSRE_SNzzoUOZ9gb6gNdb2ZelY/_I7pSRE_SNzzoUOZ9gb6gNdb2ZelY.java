import java.util.logging.Logger;
import gdt.data.store.Entigrator;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.query.Query;
public class _I7pSRE_SNzzoUOZ9gb6gNdb2ZelY  implements Query {
private final static String ENTITY_KEY="_I7pSRE_SNzzoUOZ9gb6gNdb2ZelY";
@Override
public String[] select(Entigrator entigrator){
try{
 return entigrator.indx_listEntities("entity","nwSupplier");
}catch(Exception e){
Logger.getLogger(getClass().getName());
return null;
}
}
}
