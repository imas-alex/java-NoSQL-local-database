import java.sql.Timestamp;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import gdt.data.entity.facet.ViewHandler;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.entity.view.DateHandler;
import gdt.jgui.entity.view.View;
//Sales total by amount
public class _hU7TKDMix7TYvuVkDJgwQqGiBT0  implements View {
private final static String ENTITY_KEY="_hU7TKDMix7TYvuVkDJgwQqGiBT0";

@Override
public DefaultTableModel select(Entigrator entigrator) {
	try{
		ViewHandler.performView(entigrator, "_6LKWYTB_JmBDhw7V__SFg1LnlO_M");
		
	Timestamp begin=DateHandler.getTimestamp("1997-01-01T00:00:00",null);
	Timestamp end=DateHandler.getTimestamp("1997-12-31T00:00:00",null);
	String[] sa=entigrator.indx_listEntities("entity", "nwOrder");
	Sack order;
	String orderId$=null;
	Sack customer;
	String customerId$;
	String customerKey$;
	String companyName$;
	String shippedDate$;
	String subtotal$;
	float subtotal;
	Sack id2key=entigrator.getEntityAtKey(entigrator.indx_keyAtLabel("id2key"));
	DefaultTableModel model=new DefaultTableModel();
	model.setColumnIdentifiers(new String[]{"num","SaleAmount","OrderID","CompanyName","ShippedDate"});
	int num=1;
	for(String s:sa){
		try{
		order=entigrator.getEntityAtKey(s);
		if(order==null)
			continue;
		orderId$=order.getElementItemAt("field", "OrderID");
		customerId$=order.getElementItemAt("field", "CustomerID");
		
		shippedDate$=order.getElementItemAt("field", "ShippedDate");
		if(DateHandler.getTimestamp(shippedDate$,null)==null){
			System.out.println("_hU7TKDMix7TYvuVkDJgwQqGiBT0:select:cannot get order date:order id="+order.getProperty("label"));
			continue;
		}
		if(!DateHandler.between(shippedDate$, begin, end, null))
			continue;
		subtotal$=order.getElementItemAt("var", "subtotal");
		subtotal=Float.parseFloat(subtotal$);
		if(subtotal<2500)
			continue;
		customerKey$=id2key.getElementItemAt("CustomerID", customerId$);
		customer=entigrator.getEntityAtKey(customerKey$);
		companyName$=customer.getElementItemAt("field", "CompanyName");
		model.addRow(new String[]{String.valueOf(num++),subtotal$,orderId$,companyName$,shippedDate$});
		
			}catch(Exception ee){
				System.out.println("_hU7TKDMix7TYvuVkDJgwQqGiBT0:select:orderID="+orderId$+" ee="+ee.toString());
			}
		entigrator.clearCache();
		}
	return model;
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
	
	return null;
}
@Override
public String getColumnType(String columnName$) {
	if("num".equals(columnName$))
    	return "int";
	if("OrderID".equals(columnName$))
    	return "int";
    if("SaleAmount".equals(columnName$))
    	return "float";
    return "String";

}
}
