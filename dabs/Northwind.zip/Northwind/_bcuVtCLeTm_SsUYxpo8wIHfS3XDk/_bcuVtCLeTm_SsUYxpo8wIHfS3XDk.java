import javax.swing.table.DefaultTableModel;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.entity.view.View;
//Invoices
public class _bcuVtCLeTm_SsUYxpo8wIHfS3XDk  implements View {
private final static String ENTITY_KEY="_bcuVtCLeTm_SsUYxpo8wIHfS3XDk";

@Override
public DefaultTableModel select(Entigrator entigrator) {
	
	Sack id2key=entigrator.getEntityAtKey(entigrator.indx_keyAtLabel("id2key"));
	DefaultTableModel model=new DefaultTableModel();
	model.setColumnIdentifiers(new String[]{"num",
			"ShipName",
			"ShipAddress",
			"ShipCity",
			"ShipRegion",
			"ShipPostalCode",
			"ShipCountry",
			"CustomerID",
			"CustomerName",
			"Address",
			"City",
			"Region",
			"PostalCode",
			"Country",
			"Salesperson",
			"OrderID",
			"OrderDate",
			"RequiredDate",
			"ShippedDate",
			"ShipperName",
			"ProductID",
			"ProductName",
			"UnitPrice",
			"Quantity",
			"Discount",
			"ExtendedPrice",
			"Freight"
			});
	String shipName$;
	String shipAddress$;
	String shipCity$;
	String shipRegion$;
	String shipPostalCode$;
	String shipCountry$;
	String customerID$;
	String customerName$;
	String address$;
	String city$;
	String region$;
	String postalCode$;
	String country$;
	String salesperson$;
	String orderID$;
	String orderDate$;
	String requiredDate$;
	String shippedDate$;
	String shipperName$;
	String productID$;
	String productName$;
	String unitPrice$;
	String quantity$;
	String discount$;
	String extendedPrice$;
	String freight$;
	
	String customerKey$;
	Sack customer;
	String employeeID$;
	String employeeKey$;
	Sack employee;
	
	String productKey$;
	Sack product;
	String shipVia$;
	String shipperKey$;
	Sack shipper;
	
	String[] oa=entigrator.indx_listEntities("entity", "nwOrder");
	Sack order;
	String[] da;
	Sack orderDetail;
	int num=0;
	int flag=-1;
	for(String o:oa){
		try{
		flag=0;	
			order=entigrator.getEntityAtKey(o);
		if(order==null)
			continue;
		 shipName$=order.getElementItemAt("field","ShipName");
		 shipAddress$=order.getElementItemAt("field","ShipAddress");
		 shipCity$=order.getElementItemAt("field","ShipCity");
		 shipRegion$=order.getElementItemAt("field","ShipRegion");
		 shipPostalCode$=order.getElementItemAt("field","ShipPostalCode");
		 shipCountry$=order.getElementItemAt("field","ShipCountry");
		 customerID$=order.getElementItemAt("field","CustomerID");
		 flag=1;	
		 customerKey$=id2key.getElementItemAt("CustomerID", customerID$);
		 flag=2;		
		 customer=entigrator.getEntityAtKey(customerKey$);
		 if(customer==null){
			 System.out.println("_bcuVtCLeTm_SsUYxpo8wIHfS3XDk:cannot get customer: id="+customerID$+" order="+order.getProperty("label"));
			 continue;
		 }
		 flag=3;
	     customerName$=customer.getElementItemAt("field", "CompanyName");
	     flag=4;
	     address$=customer.getElementItemAt("field", "Address");
	     city$=customer.getElementItemAt("field", "City");
	 	 region$=customer.getElementItemAt("field", "Region");
	 	 postalCode$=customer.getElementItemAt("field", "PostalCode");
	 	 country$=customer.getElementItemAt("field", "Country");
	 	 employeeID$=order.getElementItemAt("field","EmployeeID");
	 	flag=2;	
		 employeeKey$=id2key.getElementItemAt("EmployeeID", employeeID$);
	     employee=entigrator.getEntityAtKey(employeeKey$);
	     salesperson$=employee.getElementItemAt("field", "FirstName")+" "+employee.getElementItemAt("field", "LastName");
	     orderID$=order.getElementItemAt("field","OrderID");
		 orderDate$=order.getElementItemAt("field","OrderDate");
		 requiredDate$=order.getElementItemAt("field","RequiredDate");
		 shippedDate$=order.getElementItemAt("field","ShippedDate");
		 shipVia$=order.getElementItemAt("field","ShipVia");
		 shipperKey$=id2key.getElementItemAt("ShipperID", shipVia$);
		 shipper=entigrator.getEntityAtKey(shipperKey$);
		 shipperName$=shipper.getElementItemAt("field", "CompanyName");
		 da=entigrator.ent_listComponents(order);
		 freight$=order.getElementItemAt("field", "Freight");
		 for(String d:da){
			 orderDetail=entigrator.getEntityAtKey(d);
			 if(orderDetail==null)
				 continue;
			if(!"nwOrderDetail".equals(orderDetail.getProperty("entity")))
				continue;
			productID$=orderDetail.getElementItemAt("field", "ProductID");
			productKey$=id2key.getElementItemAt("ProductID", productID$);
			product=entigrator.getEntityAtKey(productKey$);
			if(product==null)
				continue;
			productName$=product.getElementItemAt("field","ProductName");
			//System.out.println("_bcuVtCLeTm_SsUYxpo8wIHfS3XDk:product name="+productName$);
			unitPrice$=orderDetail.getElementItemAt("field", "UnitPrice");
			quantity$=orderDetail.getElementItemAt("field", "Quantity");
			discount$=orderDetail.getElementItemAt("field", "Discount");
			extendedPrice$=String.valueOf(Float.parseFloat(unitPrice$)*Float.parseFloat(quantity$)*(1-Float.parseFloat(discount$)));
			model.addRow(new String[]{
					String.valueOf(num++),
					shipName$,
					shipAddress$,
					shipCity$,
					shipRegion$,
					shipPostalCode$,
					shipCountry$,
					customerID$,
					customerName$,
					address$,
					city$,
					region$,
					postalCode$,
					country$,
					salesperson$,
					orderID$,
					orderDate$,
					requiredDate$,
					shippedDate$,
					shipperName$,
					productID$,
					productName$,
					unitPrice$,
					quantity$,
					discount$,
					extendedPrice$,
					freight$
					});
		 }}catch(Exception e){
			 System.out.println("_bcuVtCLeTm_SsUYxpo8wIHfS3XDk:"+e.toString());
		 }
	entigrator.clearCache();	 
	}
	
	return model;
}

@Override
public String getColumnType(String columnName$) {
	if("num".equals(columnName$))
    	return "int";
	if("ProductID".equals(columnName$))
    	return "int";
	if("OrderID".equals(columnName$))
    	return "int";
	if("Quantity".equals(columnName$))
    	return "int";
    if("UnitPrice".equals(columnName$))
    	return "float";
    if("ExtendedPrice".equals(columnName$))
    	return "float";
    if("Discount".equals(columnName$))
    	return "float";
    if("Freight".equals(columnName$))
    	return "float";
	return "String";
}
}
