import java.util.Enumeration;
import java.util.Hashtable;
import java.util.logging.Logger;

import javax.swing.table.DefaultTableModel;

import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;

import gdt.jgui.entity.view.View;
//Products above average price
public class _eJORI0Mdo7qjI6aHCm731jSq3TM  implements View {
private final static String ENTITY_KEY="_eJORI0Mdo7qjI6aHCm731jSq3TM";

@Override
public DefaultTableModel select(Entigrator entigrator) {
	try{
	String[] sa=entigrator.indx_listEntities("entity", "nwProduct");
	Sack product;
	String unitPrice$;
	String productName$;
	Float unitPrice;
	float sumPrice=0;
	int n=0;
	Hashtable <String,Float>tab=new Hashtable<String,Float>();
	for(String s:sa){
		try{
		product=entigrator.getEntityAtKey(s);
		
		if(product==null)
			continue;
		unitPrice$=product.getElementItemAt("field", "UnitPrice");
		productName$=product.getElementItemAt("field", "ProductName");
		unitPrice=Float.parseFloat(unitPrice$);
		tab.put(productName$,unitPrice);
		sumPrice=sumPrice+unitPrice;
		n++;
		}catch(Exception ee){
			Logger.getLogger(getClass().getName()).info(ee.toString());
		}
		entigrator.clearCache();
		}
	 float averagePrice=sumPrice/n;
	 Enumeration<String> en=tab.keys();
	 int num=0;
	 DefaultTableModel model=new DefaultTableModel();
		model.setColumnIdentifiers(new String[]{"num","Product name","Unit price"});
	
	 while(en.hasMoreElements()){
		 productName$=en.nextElement();
		 unitPrice=tab.get(productName$);
		 if(unitPrice>averagePrice)
			 model.addRow(new String[]{String.valueOf(num++),productName$,String.valueOf(unitPrice)});
	 }
    return model;    	 
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
	return null;
}
@Override
public String getColumnType(String columnName$) {
	if("num".equals(columnName$))
    	return "int";
    if("Unit price".equals(columnName$))
    	return "float";
	return "String";
}
}
