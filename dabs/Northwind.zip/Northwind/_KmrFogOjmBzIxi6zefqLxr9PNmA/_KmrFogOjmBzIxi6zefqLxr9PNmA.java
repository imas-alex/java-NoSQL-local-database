import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import gdt.data.entity.facet.ViewHandler;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;

import gdt.jgui.entity.view.View;
public class _KmrFogOjmBzIxi6zefqLxr9PNmA  implements View {
private final static String ENTITY_KEY="_KmrFogOjmBzIxi6zefqLxr9PNmA";
//Summary of sales by quarter 
@Override
public DefaultTableModel select(Entigrator entigrator) {
try{
    ViewHandler.performView(entigrator, "_6LKWYTB_JmBDhw7V__SFg1LnlO_M");
String[] sa=entigrator.indx_listEntities("entity", "nwOrder");
Sack order;
String orderId$=null;
String shippedDate$;
String subtotal$;
DefaultTableModel model=new DefaultTableModel();
model.setColumnIdentifiers(new String[]{"num","Shipped Date","OrderID","Subtotal"});
int num=1;
for(String s:sa){
	try{
	order=entigrator.getEntityAtKey(s);
	if(order==null)
		continue;
	shippedDate$=order.getElementItemAt("field", "ShippedDate");
	if(shippedDate$==null)
		continue;
	subtotal$=order.getElementItemAt("var", "subtotal");
	orderId$=order.getElementItemAt("field", "OrderID");
	model.addRow(new String[]{String.valueOf(num++),shippedDate$,orderId$,subtotal$});
		}catch(Exception ee){
			System.out.println("_KmrFogOjmBzIxi6zefqLxr9PNmA:select:orderID="+orderId$+" ee="+ee.toString());
		}
	entigrator.clearCache();
	}
return model;
}catch(Exception ee){
	Logger.getLogger(getClass().getName()).severe(ee.toString());
}

return null;
}
@Override
public String getColumnType(String columnName$) {
	if("num".equals(columnName$))
    	return "int";
	if("OrderID".equals(columnName$))
    	return "int";
    if("Subtotal".equals(columnName$))
    	return "float";
    return "String";
}
}
