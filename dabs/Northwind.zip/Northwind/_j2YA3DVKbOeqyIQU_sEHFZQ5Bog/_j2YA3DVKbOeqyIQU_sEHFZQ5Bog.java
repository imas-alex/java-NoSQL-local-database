import javax.swing.table.DefaultTableModel;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.entity.view.View;
// orders details extended
public class _j2YA3DVKbOeqyIQU_sEHFZQ5Bog  implements View {
private final static String ENTITY_KEY="_j2YA3DVKbOeqyIQU_sEHFZQ5Bog";

@Override
public DefaultTableModel select(Entigrator entigrator) {
	String[] sa=entigrator.indx_listEntities("entity", "nwOrderDetail");
	System.out.println("_j2YA3DVKbOeqyIQU_sEHFZQ5Bog.select:sa="+sa.length);
	Sack id2key=entigrator.getEntityAtKey(entigrator.indx_keyAtLabel("id2key"));
	Sack orderDetail;
	String orderId$;
	String productId$;
	String productKey$;
	String productName$;
	String unitPrice$;
	String quantity$;
	String discount$;
	String extendedPrice$;
	DefaultTableModel model=new DefaultTableModel();
	model.setColumnIdentifiers(new String[]{"num",
							"OrderID"
							,"ProductID"
							,"ProductName"
							,"UnitPrice"
							,"Quantity"
							,"Discount"
							,"ExtendedPrice"
							});
	int num=0;
	for(String s:sa){
		try{
		orderDetail=entigrator.getEntityAtKey(s);
		orderId$=orderDetail.getElementItemAt("field", "OrderID");
		productId$=orderDetail.getElementItemAt("field", "ProductID");
		productKey$=id2key.getElementItemAt("ProductID", productId$);
		productName$=entigrator.indx_getLabel(productKey$);
		unitPrice$=orderDetail.getElementItemAt("field", "UnitPrice");
		quantity$=orderDetail.getElementItemAt("field", "Quantity");
		discount$=orderDetail.getElementItemAt("field", "Discount");
		extendedPrice$=String.valueOf(Float.parseFloat(unitPrice$)*Float.parseFloat(quantity$)*(1-Float.parseFloat(discount$)));
		model.addRow(new String[]{String.valueOf(num++)
									,orderId$
									,productId$
									,productName$
									,unitPrice$
									,quantity$
									,discount$
									,extendedPrice$
									
		});
		}catch(Exception e){
			System.out.println("_j2YA3DVKbOeqyIQU_sEHFZQ5Bog.select:s="+s+"::"+e.toString());
		}
		entigrator.clearCache();
	}
	return model;
}
@Override
public String getColumnType(String columnName$) {
	if("num".equals(columnName$))
    	return "int";
	if("ProductID".equals(columnName$))
    	return "int";
	if("OrderID".equals(columnName$))
    	return "int";
	if("Quantity".equals(columnName$))
    	return "int";
    if("UnitPrice".equals(columnName$))
    	return "float";
    if("ExtendedPrice".equals(columnName$))
    	return "float";
    if("Discount".equals(columnName$))
    	return "float";

	return "String";
}
}
