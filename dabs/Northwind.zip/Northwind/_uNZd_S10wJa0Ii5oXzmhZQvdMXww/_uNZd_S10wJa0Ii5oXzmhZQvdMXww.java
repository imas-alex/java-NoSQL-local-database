import java.util.logging.Logger;
import gdt.data.store.Entigrator;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.query.Query;
public class _uNZd_S10wJa0Ii5oXzmhZQvdMXww  implements Query {
private final static String ENTITY_KEY="_uNZd_S10wJa0Ii5oXzmhZQvdMXww";
@Override
public String[] select(Entigrator entigrator){
try{

return entigrator.indx_listEntities("entity", "nwCategory");

}catch(Exception e){
Logger.getLogger(getClass().getName());
return null;
}
}
}
