
import java.util.logging.Logger;

import gdt.data.store.Entigrator;
import gdt.jgui.entity.query.Query;
public class _GKWsfb8O7bpAeF1oa71LI6QQ6SI  implements Query {
private final static String ENTITY_KEY="_GKWsfb8O7bpAeF1oa71LI6QQ6SI";
@Override
public String[] select(Entigrator entigrator){
try{
return entigrator.indx_listEntities("entity", "nwProduct");
}catch(Exception e){
Logger.getLogger(getClass().getName());
return null;
}
}
}
