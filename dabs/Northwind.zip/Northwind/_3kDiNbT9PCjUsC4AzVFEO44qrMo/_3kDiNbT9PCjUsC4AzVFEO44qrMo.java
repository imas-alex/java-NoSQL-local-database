import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.entity.view.View;
//Products by category
public class _3kDiNbT9PCjUsC4AzVFEO44qrMo  implements View {
private final static String ENTITY_KEY="_3kDiNbT9PCjUsC4AzVFEO44qrMo";

@Override
public DefaultTableModel select(Entigrator entigrator) {
	try{
		String[] sa=entigrator.indx_listEntities("entity", "nwProduct");
		Sack id2key=entigrator.getEntityAtKey(entigrator.indx_keyAtLabel("id2key"));
		Sack product;
		Sack category;
		String categoryId$;
		String categoryKey$;
		String productName$;
		String categoryName$;
		String quantityPerUnit$;
		String unitsInStock$;
		String discontinued$;
		DefaultTableModel model=new DefaultTableModel();
		model.setColumnIdentifiers(new String[]{"num","Category name","Product name","Quantity per unit","Units in stock","Discontinued"});
		int num=0;
		for(String s:sa){
			try{
			product=entigrator.getEntityAtKey(s);
			if(product==null)
				continue;
			discontinued$=product.getElementItemAt("field", "Discontinued");
			if("true".equals(discontinued$))
				continue;
			categoryId$=product.getElementItemAt("field", "CategoryID");
			categoryKey$=id2key.getElementItemAt("CategoryID", categoryId$);
			category=entigrator.getEntityAtKey(categoryKey$);
			categoryName$=category.getElementItemAt("field", "CategoryName");
			//System.out.println("_3kDiNbT9PCjUsC4AzVFEO44qrMo:select:category name="+categoryName$);
			productName$=product.getElementItemAt("field", "ProductName");
			quantityPerUnit$=product.getElementItemAt("field", "QuantityPerUnit");
			unitsInStock$=product.getElementItemAt("field", "UnitsInStock");
			model.addRow(new String[]{String.valueOf(num++),categoryName$,productName$,quantityPerUnit$,unitsInStock$,discontinued$});
			}catch(Exception ee){
				Logger.getLogger(getClass().getName()).info(ee.toString());
			}
			entigrator.clearCache();
			}
	    return model;    	 
		}catch(Exception e){
			Logger.getLogger(getClass().getName()).severe(e.toString());
		}
		return null;
}
@Override
public String getColumnType(String columnName$) {
	if("num".equals(columnName$))
    	return "int";
    if("Units in stock".equals(columnName$))
    	return "int";
	return "String";
}
}
