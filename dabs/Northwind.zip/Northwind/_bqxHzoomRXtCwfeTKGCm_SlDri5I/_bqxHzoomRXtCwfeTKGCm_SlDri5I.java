import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;
import gdt.data.entity.EntityHandler;
import gdt.data.entity.facet.ExtensionHandler;
import gdt.data.grain.Locator;
import gdt.data.store.Entigrator;
import gdt.jgui.base.ProgressDialog;
import gdt.jgui.console.JConsoleHandler;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.procedure.JProcedurePanel;
import gdt.jgui.entity.procedure.Procedure;
import java.util.ArrayList;
import java.util.Collections;
public class _bqxHzoomRXtCwfeTKGCm_SlDri5I  implements Procedure {
private final static String ENTITY_KEY="_bqxHzoomRXtCwfeTKGCm_SlDri5I";
@Override
public void run(JMainConsole console,String entihome$,Integer dividerLocation){
try{
//Do NOT change this section of the code
Entigrator entigrator=console.getEntigrator(entihome$);
String label$=entigrator.indx_getLabel(ENTITY_KEY);
// Put procedure code here
String [] sa=entigrator.indx_listEntitiesAtPropertyName("entity");
ArrayList<String>sl=new ArrayList<String>();
 for(String s:sa)
sl.add(entigrator.indx_getLabel(s));
 Collections.sort(sl);
//
//Do NOT change this section of the code
File report=new File(entihome$+"/"+ENTITY_KEY+"/report.txt");
if(!report.exists())
	report.createNewFile();
Date curDate = new Date();
SimpleDateFormat format = new SimpleDateFormat();
format = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
String date$= format.format(curDate);
FileOutputStream fos = new FileOutputStream(report, false);
Writer writer = new OutputStreamWriter(fos, "UTF-8");
writer.write("Report:   "+label$+"\n");
writer.write(date$+"\n");
writer.write("__________ Rebuild components _____________\n");
//Put report code here
for(String s:sl)
	writer.write(s+"\n");
//Do NOT change this section of the code
writer.close();
Runnable process=new Runnable(){

	@Override
	public void run() {
		try{
		Object sourceHandler=ExtensionHandler.loadHandlerInstance( entigrator,"_ebrysyRG3lk1CYHiugIoSapofvo","gdt.data.entity.NwSourceHandler");
		Class tClass = sourceHandler.getClass();
		Method[] methods = tClass.getDeclaredMethods();
		for (int i = 0; i < methods.length; i++) {
			if("rebuildRelations".equals(methods[i].getName()))
				methods[i].invoke(sourceHandler, entigrator);
		}	
		}catch(Exception e){
			Logger.getLogger(getClass().getName()).severe(e.toString());
		}
	}
	
};
ProgressDialog pd=new ProgressDialog(console.getFrame(),process,"Wait for ..");	
pd.setLocationRelativeTo(console.getContentPanel());
pd.setVisible(true);
}catch(Exception e){
Logger.getLogger(getClass().getName());
}
}
@Override
public void run(Entigrator entigrator, Integer dividerLocation) {
	// TODO Auto-generated method stub
	
}
}
