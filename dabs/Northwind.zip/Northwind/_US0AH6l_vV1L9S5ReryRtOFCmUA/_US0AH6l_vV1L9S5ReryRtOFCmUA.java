import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.entity.view.DateHandler;
import gdt.jgui.entity.view.View;
//Product sales for 1997
public class _US0AH6l_vV1L9S5ReryRtOFCmUA  implements View {
private final static String ENTITY_KEY="_US0AH6l_vV1L9S5ReryRtOFCmUA";

@Override
public DefaultTableModel select(Entigrator entigrator) {
	try{

		
		String[] sa=entigrator.indx_listEntities("entity", "nwOrder");
		Sack order;
		Sack orderDetail;
		String shippedDate$;
		ArrayList <String>sl=new ArrayList<String>();
		String[] oda;
		String unitPrice$;
		float unitPrice;
		String quontity$;
		int quontity;
		String productId$;
		String productKey$;
		String productName$;
		Sack product;
		
		String categoryId$;
		String categoryKey$;
		Sack category;
		String discount$;
		float discount;
		float detailPrice;
		Float productSum;
		String categoryName$;
		Sack id2key=entigrator.getEntityAtKey(entigrator.indx_keyAtLabel("id2key"));
		Hashtable<String,Float>sum=new Hashtable<String,Float>();
		Hashtable<String,String>cats=new Hashtable<String,String>();
		Timestamp begin=DateHandler.getTimestamp("1997-01-01T00:00:00",null);
		Timestamp end=DateHandler.getTimestamp("1997-12-31T00:00:00",null);
		for(String s:sa){
			try{
			order=entigrator.getEntityAtKey(s);
			if(order==null)
				continue;
			shippedDate$=order.getElementItemAt("field", "ShippedDate");
			oda=entigrator.ent_listComponents(order);
			if(oda==null)
				continue;
			//shippedTime=null;
			//if(shippedDate$!=null)
			
			if(DateHandler.getTimestamp(shippedDate$,null)==null){
				System.out.println("_US0AH6l_vV1L9S5ReryRtOFCmUA:select:order id="+order.getProperty("label"));
				continue;
			}
				
			
			if(!DateHandler.between(shippedDate$, begin, end, null))
				continue;
			for(String od:oda){
				try{
				detailPrice=0;
				orderDetail=entigrator.getEntityAtKey(od);
				if(orderDetail==null)
					continue;
				unitPrice$=orderDetail.getElementItemAt("field", "UnitPrice");
				quontity$=orderDetail.getElementItemAt("field", "Quantity");
				discount$=orderDetail.getElementItemAt("field", "Discount");
				productId$=orderDetail.getElementItemAt("field", "ProductID");
				productKey$=id2key.getElementItemAt("ProductID", productId$);
				product=entigrator.getEntityAtKey(productKey$);
				categoryId$=product.getElementItemAt("field", "CategoryID");
				productName$=product.getElementItemAt("field", "ProductName");
				categoryKey$=id2key.getElementItemAt("CategoryID", categoryId$);
				category=entigrator.getEntityAtKey(categoryKey$);
				categoryName$=category.getElementItemAt("field", "CategoryName");
				//System.out.println("_y4T_Mr7bmULI_gSotq_SOF9JYTas:select:category name="+categoryName$);
				if(!sl.contains(productName$)){
				    sl.add(productName$);
				    cats.put(productName$, categoryName$);
				   // System.out.println("_y4T_Mr7bmULI_gSotq_SOF9JYTas:select:category name="+categoryName$);
				}
					unitPrice=Float.parseFloat(unitPrice$);
					quontity=Integer.parseInt(quontity$);
					discount=Float.parseFloat(discount$);
					detailPrice=unitPrice*quontity*(1-discount);
					productSum=sum.get(productName$);
					if(productSum!=null){
						productSum=new Float(detailPrice+productSum.floatValue());
						sum.put(productName$,productSum);
					}else{
						sum.put(productName$,new Float(detailPrice));
					}
						
				}catch(Exception ee){
					System.out.println("_y4T_Mr7bmULI_gSotq_SOF9JYTas:select:ee="+ee.toString());
				}
			}
			
		}catch(Exception eee){
			System.out.println("_y4T_Mr7bmULI_gSotq_SOF9JYTas:select:eee="+eee.toString());
		}
			entigrator.clearCache();
		}
		//System.out.println("_y4T_Mr7bmULI_gSotq_SOF9JYTas:select:sl="+sl.size());
		Collections.sort(sl);
		DefaultTableModel model=new DefaultTableModel();
		model.setColumnIdentifiers(new String[]{"num","Category name","Product name","Product sales"});
		int num=0;
		for(String s:sl){
			productSum=sum.get(s);
		//	 System.out.println("_y4T_Mr7bmULI_gSotq_SOF9JYTas:select:category name="+s+" sum="+categorySum);
			model.addRow(new String[]{String.valueOf(num++),cats.get(s),s,String.valueOf(productSum)});
		}
		return model;
		}catch(Exception e){
			Logger.getLogger(getClass().getName()).severe(e.toString());
		}
		return null;
}
@Override
public String getColumnType(String columnName$) {
	if("num".equals(columnName$))
    	return "int";
    if("Product sales".equals(columnName$))
    	return "float";
	return "String";
}
}
