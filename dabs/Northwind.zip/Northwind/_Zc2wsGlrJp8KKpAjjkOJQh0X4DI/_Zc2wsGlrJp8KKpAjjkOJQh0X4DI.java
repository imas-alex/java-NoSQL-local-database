import javax.swing.table.DefaultTableModel;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.entity.view.View;
// Customers and suppliers by city
public class _Zc2wsGlrJp8KKpAjjkOJQh0X4DI  implements View {
private final static String ENTITY_KEY="_Zc2wsGlrJp8KKpAjjkOJQh0X4DI";

@Override
public DefaultTableModel select(Entigrator entigrator) {
	String[] sa=entigrator.indx_listEntities("entity", "nwSupplier");
	String[] ca=entigrator.indx_listEntities("entity", "nwCustomer");
	DefaultTableModel model=new DefaultTableModel();
	model.setColumnIdentifiers(new String[]{"num","City","CompanyName","ContactName","Relationship"});
	int num=0;
	Sack supplier;
	for(String s:sa){
	supplier=entigrator.getEntityAtKey(s);
	if(supplier!=null)
       model.addRow(new String[]{String.valueOf(num++)
    		   			,supplier.getElementItemAt("field", "City")
    		            ,supplier.getElementItemAt("field", "CompanyName")
    		            ,supplier.getElementItemAt("field", "CompanyName")
    		            ,"Supplier"}
    		            );   	
	entigrator.clearCache();
	}
	for(String s:ca){
		supplier=entigrator.getEntityAtKey(s);
		if(supplier!=null)
	       model.addRow(new String[]{String.valueOf(num++)
	    		   			,supplier.getElementItemAt("field", "City")
	    		            ,supplier.getElementItemAt("field", "CompanyName")
	    		            ,supplier.getElementItemAt("field", "CompanyName")
	    		            ,"Customer"}
	    		            ); 
		entigrator.clearCache();
		}
	
	return model;
}

@Override
public String getColumnType(String columnName$) {
	 if("num".equals(columnName$))
	    	return "int";
	return "String";
}
}
