import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;
import gdt.data.entity.EntityHandler;
import gdt.data.entity.facet.FieldsHandler;
import gdt.data.grain.Core;
import gdt.data.grain.Locator;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.console.JConsoleHandler;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.procedure.JProcedurePanel;
import gdt.jgui.entity.procedure.Procedure;
import java.util.ArrayList;
import java.util.Collections;
public class _D3316A_Sp44He95QNU4NQM_Swg160  implements Procedure {
private final static String ENTITY_KEY="_D3316A_Sp44He95QNU4NQM_Swg160";
@Override
public void run(JMainConsole console,String entihome$,Integer dividerLocation){
try{
//Do NOT change this section of the code
Entigrator entigrator=console.getEntigrator(entihome$);
String label$=entigrator.indx_getLabel(ENTITY_KEY);
// Put procedure code here

try{
	Sack id2key=null;
	String id2key$=entigrator.indx_keyAtLabel("id2key");
	if(id2key$!=null)
	    id2key=entigrator.getEntityAtKey(id2key$);
	if(id2key!=null)
		entigrator.deleteEntity(id2key);
	 id2key=entigrator.ent_new("fields", "id2key");
		id2key.createElement("fhandler");
		id2key.putElementItem("fhandler", new Core(null,FieldsHandler.class.getName(),null));
		id2key.putAttribute(new Core (null,"icon","fields.png"));
		entigrator.replace(id2key);
		id2key=entigrator.ent_reindex(id2key);
	Sack candidate;
	String id$;
	if(id2key.existsElement("CategoryID"))
	   id2key.removeElement("CategoryID");
	String [] sa=entigrator.indx_listEntities("entity", "nwCategory");
	if(sa!=null){
		id2key.createElement("CategoryID");
		for(String s:sa){
		candidate=entigrator.getEntityAtKey(s);
		if(candidate!=null){
			id$=candidate.getElementItemAt("field", "CategoryID");
			if(id$!=null)
				id2key.putElementItem("CategoryID", new Core(null,id$,s));
		}
		}
	}
	if(id2key.existsElement("CustomerID"))
		   id2key.removeElement("CustomerID");
		sa=entigrator.indx_listEntities("entity", "nwCustomer");
		if(sa!=null){
			id2key.createElement("CustomerID");
			for(String s:sa){
			candidate=entigrator.getEntityAtKey(s);
			if(candidate!=null){
				id$=candidate.getElementItemAt("field", "CustomerID");
				if(id$!=null)
					id2key.putElementItem("CustomerID", new Core(null,id$,s));
			}
			}
		}
		if(id2key.existsElement("EmployeeID"))
			   id2key.removeElement("EmployeeID");
			sa=entigrator.indx_listEntities("entity", "nwEmployee");
			if(sa!=null){
				id2key.createElement("EmployeeID");
				for(String s:sa){
				candidate=entigrator.getEntityAtKey(s);
				if(candidate!=null){
					id$=candidate.getElementItemAt("field", "EmployeeID");
					if(id$!=null)
						id2key.putElementItem("EmployeeID", new Core(null,id$,s));
				}
				}
			}
			if(id2key.existsElement("OrderID"))
				   id2key.removeElement("OrderID");
				sa=entigrator.indx_listEntities("entity", "nwOrder");
				if(sa!=null){
					id2key.createElement("OrderID");
					for(String s:sa){
					candidate=entigrator.getEntityAtKey(s);
					if(candidate!=null){
						id$=candidate.getElementItemAt("field", "OrderID");
						if(id$!=null)
							id2key.putElementItem("OrderID", new Core(null,id$,s));
					}
					}
				}	
			if(id2key.existsElement("ProductID"))
					   id2key.removeElement("ProductID");
					sa=entigrator.indx_listEntities("entity", "nwProduct");
					if(sa!=null){
						id2key.createElement("ProductID");
						for(String s:sa){
						candidate=entigrator.getEntityAtKey(s);
						if(candidate!=null){
							id$=candidate.getElementItemAt("field", "ProductID");
							if(id$!=null)
								id2key.putElementItem("ProductID", new Core(null,id$,s));
						}
						}
					}
			if(id2key.existsElement("RegionID"))
						   id2key.removeElement("RegionID");
						sa=entigrator.indx_listEntities("entity", "nwRegion");
						if(sa!=null){
							id2key.createElement("RegionID");
							for(String s:sa){
							candidate=entigrator.getEntityAtKey(s);
							if(candidate!=null){
								id$=candidate.getElementItemAt("field", "RegionID");
								if(id$!=null)
									id2key.putElementItem("RegionID", new Core(null,id$,s));
							}
							}
						}
			if(id2key.existsElement("ShipperID"))
							   id2key.removeElement("ShipperID");
							sa=entigrator.indx_listEntities("entity", "nwShipper");
							if(sa!=null){
								id2key.createElement("ShipperID");
								for(String s:sa){
								candidate=entigrator.getEntityAtKey(s);
								if(candidate!=null){
									id$=candidate.getElementItemAt("field", "ShipperID");
									if(id$!=null)
										id2key.putElementItem("ShipperID", new Core(null,id$,s));
								}
								}
							}
				if(id2key.existsElement("SupplierID"))
								   id2key.removeElement("SupplierID");
								sa=entigrator.indx_listEntities("entity", "nwSupplier");
								if(sa!=null){
									id2key.createElement("SupplierID");
									for(String s:sa){
									candidate=entigrator.getEntityAtKey(s);
									if(candidate!=null){
										id$=candidate.getElementItemAt("field", "SupplierID");
										if(id$!=null)
											id2key.putElementItem("SupplierID", new Core(null,id$,s));
									}
									}
								}								
	entigrator.replace(id2key);
	entigrator.ent_reindex(id2key);
}catch(Exception e){
	Logger.getLogger(getClass().getName()).severe(e.toString());
}
//
//Do NOT change this section of the code
File report=new File(entihome$+"/"+ENTITY_KEY+"/report.txt");
if(!report.exists())
	report.createNewFile();
Date curDate = new Date();
SimpleDateFormat format = new SimpleDateFormat();
format = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
String date$= format.format(curDate);
FileOutputStream fos = new FileOutputStream(report, false);
Writer writer = new OutputStreamWriter(fos, "UTF-8");
writer.write("Report:   "+label$+"\n");
writer.write(date$+"\n");
writer.write("__________ Done id2key _____________\n");
//Put report code here

//Do NOT change this section of the code
writer.close();
JProcedurePanel jpp=new JProcedurePanel();
String jppLocator$=jpp.getLocator();
jppLocator$=Locator.append(jppLocator$, Entigrator.ENTIHOME, entihome$);
jppLocator$=Locator.append(jppLocator$, EntityHandler.ENTITY_KEY,ENTITY_KEY);
jppLocator$=Locator.append(jppLocator$, JProcedurePanel.DIVIDER_LOCATION,String.valueOf(dividerLocation));
JConsoleHandler.execute(console, jppLocator$);
}catch(Exception e){
Logger.getLogger(getClass().getName());
}
}
@Override
public void run(Entigrator entigrator, Integer dividerLocation) {
	// TODO Auto-generated method stub
	
}
}
