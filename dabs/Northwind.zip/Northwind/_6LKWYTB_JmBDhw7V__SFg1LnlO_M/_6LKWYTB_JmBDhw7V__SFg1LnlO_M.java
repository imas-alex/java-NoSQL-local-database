import java.sql.Timestamp;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.logging.Logger;

import javax.swing.table.DefaultTableModel;

import gdt.data.grain.Core;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.entity.view.DateHandler;
import gdt.jgui.entity.view.View;
//Orders subtotals
public class _6LKWYTB_JmBDhw7V__SFg1LnlO_M  implements View {
private final static String ENTITY_KEY="_6LKWYTB_JmBDhw7V__SFg1LnlO_M";

@Override
public DefaultTableModel select(Entigrator entigrator) {
	Timestamp begin=null;
	Timestamp end=null;
	Sack view=entigrator.getEntityAtKey(ENTITY_KEY); 
	String begin$=view.getElementItemAt("parameter", "begin");
	String end$=view.getElementItemAt("parameter", "end");
	String date$=view.getElementItemAt("parameter", "date");
	try{begin=DateHandler.getTimestamp(begin$,null);}catch(Exception e){}
	try{end=DateHandler.getTimestamp(end$,null);}catch(Exception e){}
	
	
	String[] soa=entigrator.indx_listEntities("entity", "nwOrder");
	String[] sda=entigrator.indx_listEntities("entity", "nwOrderDetail");
	Sack id2key=entigrator.getEntityAtKey(entigrator.indx_keyAtLabel("id2key"));

	Sack orderDetail;
	String orderId$;
	String orderKey$;
	String unitPrice$;
	String quantity$;
	String discount$;
	String subtotal$;
	String shippedDate$;
	//String orderDate$;
	float subtotal;
	Sack order;
	for(String s:soa){
		try{
		order=entigrator.getEntityAtKey(s);
		if(order.existsElement("var")){
			order.removeElement("var");
			entigrator.save(order);
		}
		
		}catch(Exception e){
			Logger.getLogger(getClass().getName()).info(e.toString());
		}
	}
	DefaultTableModel model=new DefaultTableModel();
	model.setColumnIdentifiers(new String[]{"num",
							"OrderID"
							,"Subtotal"
							
							});
	int num=0;
	Hashtable<String,String> subtotals=new Hashtable<String,String>();  
	for(String s:sda){
		try{
		orderDetail=entigrator.getEntityAtKey(s);
		orderId$=orderDetail.getElementItemAt("field", "OrderID");
		orderKey$=id2key.getElementItemAt("OrderID", orderId$);
		order=entigrator.getEntityAtKey(orderKey$);
		shippedDate$=order.getElementItemAt("field", "ShippedDate");
		//orderDate$=order.getElementItemAt("field", "OrderDate");
		if(begin!=null&&end!=null)
			if(!DateHandler.between(shippedDate$, begin, end, null))
				continue;
		if(!order.existsElement("var")){
			order.createElement("var");
			order.putElementItem("var", new Core(null,"subtotal","0"));
		}
		
		subtotal$=order.getElementItemAt("var", "subtotal");
		
		subtotal=Float.parseFloat(subtotal$);
		unitPrice$=orderDetail.getElementItemAt("field", "UnitPrice");
		quantity$=orderDetail.getElementItemAt("field", "Quantity");
		discount$=orderDetail.getElementItemAt("field", "Discount");
		subtotal$=String.valueOf(subtotal+ Float.parseFloat(unitPrice$)*Float.parseFloat(quantity$)*(1-Float.parseFloat(discount$)));
		order.putElementItem("var", new Core(null,"subtotal",subtotal$));
		subtotals.put(orderId$, subtotal$);
		entigrator.save(order);
		}catch(Exception e){
			Logger.getLogger(getClass().getName()).info(e.toString());
		}
	entigrator.clearCache();	
	}
	
	Enumeration<String> orderIds=subtotals.keys();
	while(orderIds.hasMoreElements()){
		orderId$=orderIds.nextElement();
		model.addRow(new String[]{String.valueOf(num++)
				,orderId$
				,subtotals.get(orderId$)
				
				
});
	}
	
	return model;
}
@Override
public String getColumnType(String columnName$) {
	if("num".equals(columnName$))
    	return "int";
	if("OrderID".equals(columnName$))
    	return "int";
    if("Subtotal".equals(columnName$))
    	return "float";

	return "String";
}
}
