import java.util.logging.Logger;
import gdt.data.store.Entigrator;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.query.Query;
public class _CAILuap9BHvXW_SckoOWRJE3aHcs  implements Query {
private final static String ENTITY_KEY="_CAILuap9BHvXW_SckoOWRJE3aHcs";
@Override
public String[] select(Entigrator entigrator){
try{
 return entigrator.indx_listEntities("entity","nwShipper");
}catch(Exception e){
Logger.getLogger(getClass().getName());
return null;
}
}
}
