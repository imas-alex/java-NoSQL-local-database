import java.util.logging.Logger;
import gdt.data.store.Entigrator;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.query.Query;
public class _acacXo2ewpnpk92ZCZWG6ie_awI  implements Query {
private final static String ENTITY_KEY="_acacXo2ewpnpk92ZCZWG6ie_awI";
@Override
public String[] select(Entigrator entigrator){
try{
//String entihome$=entigrator.getEntihome();
System.out.println("_acacXo2ewpnpk92ZCZWG6ie_awI.select:BEGIN");
entigrator.clearCache();
String[] sa=entigrator.indx_listEntities("entity","nwOrderDetail");

System.out.println("_acacXo2ewpnpk92ZCZWG6ie_awI.select:sa="+sa.length);

return sa;
}catch(Exception e){
Logger.getLogger(getClass().getName());
return null;
}
}
}
