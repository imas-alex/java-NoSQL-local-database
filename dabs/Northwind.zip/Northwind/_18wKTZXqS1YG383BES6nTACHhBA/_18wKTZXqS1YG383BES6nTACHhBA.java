import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.entity.view.DateHandler;
import gdt.jgui.entity.view.View;
//Quartery orders
public class _18wKTZXqS1YG383BES6nTACHhBA  implements View {
private final static String ENTITY_KEY="_18wKTZXqS1YG383BES6nTACHhBA";

@Override
public DefaultTableModel select(Entigrator entigrator) {
try{
		String[] sa=entigrator.indx_listEntities("entity", "nwOrder");
		Sack order;
		Sack customer;
		String orderDate$;
		ArrayList <String>sl=new ArrayList<String>();
		String customerId$;
		String customerKey$;
		String companyName$;
		String city$;
		String country$;
		Sack id2key=entigrator.getEntityAtKey(entigrator.indx_keyAtLabel("id2key"));
		Timestamp begin=DateHandler.getTimestamp("1997-01-01T00:00:00",null);
		Timestamp end=DateHandler.getTimestamp("1997-12-31T00:00:00",null);
		DefaultTableModel model=new DefaultTableModel();
		model.setColumnIdentifiers(new String[]{"num","CustomerID","CompanyName","City","Country"});
		int num=1;
		for(String s:sa){
			try{
			order=entigrator.getEntityAtKey(s);
			if(order==null)
				continue;
			customerId$=order.getElementItemAt("field", "CustomerID");
			if(sl.contains(customerId$))
				continue;
			orderDate$=order.getElementItemAt("field", "OrderDate");
			if(DateHandler.getTimestamp(orderDate$,null)==null){
				System.out.println("_18wKTZXqS1YG383BES6nTACHhBA:select:cannot get order date:order id="+order.getProperty("label"));
				continue;
			}
			if(!DateHandler.between(orderDate$, begin, end, null))
				continue;
			customerKey$=id2key.getElementItemAt("CustomerID", customerId$);
			customer=entigrator.getEntityAtKey(customerKey$);
			companyName$=customer.getElementItemAt("field", "CompanyName");
			city$=customer.getElementItemAt("field", "City");
			country$=customer.getElementItemAt("field", "Country");
			model.addRow(new String[]{String.valueOf(num++),customerId$,companyName$,city$,country$});
			sl.add(customerId$);
				}catch(Exception ee){
					System.out.println("_18wKTZXqS1YG383BES6nTACHhBA:select:ee="+ee.toString());
				}
			entigrator.clearCache();
			}
		return model;
		}catch(Exception e){
			Logger.getLogger(getClass().getName()).severe(e.toString());
		}
		return null;
}
@Override
public String getColumnType(String columnName$) {
	if("num".equals(columnName$))
    	return "int";
    if("Customer ID".equals(columnName$))
    	return "int";
	return "String";
}
}
