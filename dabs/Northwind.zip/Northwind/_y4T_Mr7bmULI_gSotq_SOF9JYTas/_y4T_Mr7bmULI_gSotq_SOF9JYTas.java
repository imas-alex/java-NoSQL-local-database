import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
//import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.view.View;
// Category sales
public class _y4T_Mr7bmULI_gSotq_SOF9JYTas  implements View {
private final static String ENTITY_KEY="_y4T_Mr7bmULI_gSotq_SOF9JYTas";
@Override
public DefaultTableModel select(Entigrator entigrator) {
	try{

	
	String[] sa=entigrator.indx_listEntities("entity", "nwOrder");
	Sack order;
	Sack orderDetail;
	String shippedDate$;
	ArrayList <String>sl=new ArrayList<String>();
	String[] oda;
	String unitPrice$;
	float unitPrice;
	String quontity$;
	int quontity;
	String productId$;
	String productKey$;
	Sack product;
	String categoryId$;
	String categoryKey$;
	Sack category;
	String discount$;
	float discount;
	float detailPrice;
	Float categorySum;
	String categoryName$;
	Sack id2key=entigrator.getEntityAtKey(entigrator.indx_keyAtLabel("id2key"));
	Hashtable<String,Float>sum=new Hashtable<String,Float>();
	for(String s:sa){
		try{
		order=entigrator.getEntityAtKey(s);
		if(order==null)
			continue;
		shippedDate$=order.getElementItemAt("field", "ShippedDate");
		oda=entigrator.ent_listComponents(order);
		if(oda==null)
			continue;
		for(String od:oda){
			try{
			detailPrice=0;
			orderDetail=entigrator.getEntityAtKey(od);
			if(orderDetail==null)
				continue;
			unitPrice$=orderDetail.getElementItemAt("field", "UnitPrice");
			quontity$=orderDetail.getElementItemAt("field", "Quantity");
			discount$=orderDetail.getElementItemAt("field", "Discount");
			productId$=orderDetail.getElementItemAt("field", "ProductID");
			productKey$=id2key.getElementItemAt("ProductID", productId$);
			product=entigrator.getEntityAtKey(productKey$);
			categoryId$=product.getElementItemAt("field", "CategoryID");
			categoryKey$=id2key.getElementItemAt("CategoryID", categoryId$);
			category=entigrator.getEntityAtKey(categoryKey$);
			categoryName$=category.getElementItemAt("field", "CategoryName");
			//System.out.println("_y4T_Mr7bmULI_gSotq_SOF9JYTas:select:category name="+categoryName$);
			if(!sl.contains(categoryName$)){
			    sl.add(categoryName$);	
			   // System.out.println("_y4T_Mr7bmULI_gSotq_SOF9JYTas:select:category name="+categoryName$);
			}
				unitPrice=Float.parseFloat(unitPrice$);
				quontity=Integer.parseInt(quontity$);
				discount=Float.parseFloat(discount$);
				detailPrice=unitPrice*quontity*(1-discount);
				categorySum=sum.get(categoryName$);
				if(categorySum!=null){
					categorySum=new Float(detailPrice+categorySum.floatValue());
					sum.put(categoryName$,categorySum);
				}else{
					sum.put(categoryName$,new Float(detailPrice));
				}
					
			}catch(Exception ee){
				System.out.println("_y4T_Mr7bmULI_gSotq_SOF9JYTas:select:ee="+ee.toString());
			}
		}
		
	}catch(Exception eee){
		System.out.println("_y4T_Mr7bmULI_gSotq_SOF9JYTas:select:eee="+eee.toString());
	}
		entigrator.clearCache();
	}
	//System.out.println("_y4T_Mr7bmULI_gSotq_SOF9JYTas:select:sl="+sl.size());
	Collections.sort(sl);
	DefaultTableModel model=new DefaultTableModel();
	model.setColumnIdentifiers(new String[]{"num","Category name","Category sales"});
	int num=0;
	for(String s:sl){
		categorySum=sum.get(s);
	//	 System.out.println("_y4T_Mr7bmULI_gSotq_SOF9JYTas:select:category name="+s+" sum="+categorySum);
		model.addRow(new String[]{String.valueOf(num++),s,String.valueOf(categorySum)});
	}
	return model;
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
	return null;
}

public String getColumnType(String columnName$) {
	 if("num".equals(columnName$))
	    	return "int";
	    if("Category sales".equals(columnName$))
	    	return "float";
		return "String";
}
}
