import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import javax.swing.table.DefaultTableModel;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.entity.view.View;
// Current products list
public class __aTt00zfR_Sh6NEVLyUpJe7Qv_Slo  implements View {
private final static String ENTITY_KEY="__aTt00zfR_Sh6NEVLyUpJe7Qv_Slo";

@Override
public DefaultTableModel select(Entigrator entigrator) {
	String[] sa=entigrator.indx_listEntities("entity", "nwProduct");
	Sack product;
	ArrayList <String>sl=new ArrayList<String>();
	Hashtable<String,String>tab=new Hashtable<String,String>();
	String productName$;
	String productId$;
	for(String s:sa){
		product=entigrator.getEntityAtKey(s);
		if("true".equals(product.getElementItem("field", "Discontinued")))
			continue;
		productName$=product.getElementItemAt("field", "ProductName");
		productId$=product.getElementItemAt("field", "ProductID");
		if(!sl.contains(productName$)){
			tab.put(productName$, productId$);
			sl.add(productName$);
		}
		entigrator.clearCache();
	}
	Collections.sort(sl);
	DefaultTableModel model=new DefaultTableModel();
	model.setColumnIdentifiers(new String[]{"num","ProductID","ProductName"});
	int num=0;
	for(String s:sl){
	
	//	 System.out.println("__aTt00zfR_Sh6NEVLyUpJe7Qv_Slo:select product name="+s+" id="+tab.get(s));
		model.addRow(new String[]{String.valueOf(num++),tab.get(s),s});
	}
	return model;
	
}

@Override
public String getColumnType(String columnName$) {
    if("num".equals(columnName$))
    	return "int";
    if("ProductID".equals(columnName$))
    	return "int";
	return "String";
}
}
