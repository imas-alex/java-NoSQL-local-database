import java.util.logging.Logger;
import gdt.data.store.Entigrator;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.query.Query;
public class _9_5lLak7pUJEzL7qCtPObpZgyK0  implements Query {
private final static String ENTITY_KEY="_9_5lLak7pUJEzL7qCtPObpZgyK0";
@Override
public String[] select(Entigrator entigrator){
try{
 return entigrator.indx_listEntities("entity","nwOrder");

}catch(Exception e){
Logger.getLogger(getClass().getName());
return null;
}
}
}
