import java.util.logging.Logger;
import gdt.data.store.Entigrator;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.query.Query;
public class _lbAbMOBdz6_offavLBKYmj3SPNs  implements Query {
private final static String ENTITY_KEY="_lbAbMOBdz6_offavLBKYmj3SPNs";
@Override
public String[] select(Entigrator entigrator){
try{
return entigrator.indx_listEntities("entity", "nwEmployee");

}catch(Exception e){
Logger.getLogger(getClass().getName());
return null;
}
}
}
