import java.util.logging.Logger;
import gdt.data.store.Entigrator;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.query.Query;
public class _2DOtCo5e_S6ARWU0H_MtyFnnPThE  implements Query {
private final static String ENTITY_KEY="_2DOtCo5e_S6ARWU0H_MtyFnnPThE";

@Override
public String[] select(Entigrator entigrator) {
	try{
		//Do NOT change this section of the code
		
		String [] sa;
		// Put query code here
		sa=entigrator.indx_listEntitiesAtPropertyName("entity");
		//
		//Do NOT change this section of the code
		return sa;
		}catch(Exception e){
		Logger.getLogger(getClass().getName());
		return null;
		}
}
}
