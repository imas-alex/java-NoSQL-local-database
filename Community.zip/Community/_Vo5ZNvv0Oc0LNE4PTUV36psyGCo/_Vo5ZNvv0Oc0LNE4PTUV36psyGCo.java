import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Logger;
import gdt.data.entity.EntityHandler;
import gdt.data.grain.Core;
import gdt.data.grain.Locator;
import gdt.data.grain.Sack;
import gdt.data.store.Entigrator;
import gdt.jgui.console.JConsoleHandler;
import gdt.jgui.console.JMainConsole;
import gdt.jgui.entity.index.JIndexPanel;
import gdt.jgui.entity.procedure.JProcedurePanel;
import gdt.jgui.entity.procedure.Procedure;
import java.util.ArrayList;
import java.util.Collections;
public class _Vo5ZNvv0Oc0LNE4PTUV36psyGCo  implements Procedure {
private final static String ENTITY_KEY="_Vo5ZNvv0Oc0LNE4PTUV36psyGCo";
@Override
public void run(JMainConsole console,String entihome$,Integer dividerLocation){
try{
//	System.out.println("Reset:run:BEGIN:entihome="+entihome$);
Entigrator entigrator=console.getEntigrator(entihome$);
String label$=entigrator.indx_getLabel(ENTITY_KEY);
//Delete Cleopatra from the database
String cleopatraKey$=entigrator.indx_keyAtLabel("Cleopatra");
System.out.println("Reset:run:Cleopatra key="+cleopatraKey$);
if(cleopatraKey$!=null){
	Sack cleopatra=entigrator.getEntityAtKey(cleopatraKey$);
	entigrator.deleteEntity(cleopatra);
}else
	System.out.println("Reset:run:cannot find Cleopatra");
//Delete Emperors from Favorites
String favoritesKey$=entigrator.indx_keyAtLabel("Favorites");
if(favoritesKey$!=null){
	Sack favorites=entigrator.getEntityAtKey(favoritesKey$);
	Core[] ca=favorites.elementGet("index.jlocator");
	if(ca!=null){
		Properties locator;
		String title$;
		String type$;
		String groupKey$;
		String nodeKey$;
		ArrayList <String>sl=new ArrayList<String>();
		//Find Emperors key
		String emperorsKey$=null;
		for(Core c:ca){
			try{
				locator=Locator.toProperties(c.value);
				title$=locator.getProperty(Locator.LOCATOR_TITLE);
				type$=locator.getProperty(JIndexPanel.NODE_TYPE);
				nodeKey$=locator.getProperty(JIndexPanel.NODE_KEY);
				groupKey$=locator.getProperty(JIndexPanel.NODE_GROUP_KEY);
				if("parent".equals(groupKey$)
						&&"Emperors".equals(title$)){
					emperorsKey$=nodeKey$;
					System.out.println("Reset:run:found Emperors key="+emperorsKey$);
					sl.add(c.name);
					break;
				//System.out.println("Reset:run:item title="+title$+" type="+type$+" group key="+groupKey$+" node key="+nodeKey$);
				}
			}catch(Exception e){
				System.out.println("Reset:run:"+e.toString());
			}
		}
		if(emperorsKey$==null){
			System.out.println("Reset:run:cannot find Emperors key");
			return;
		}
		//Find Emperors members
				for(Core c:ca){
					try{
						locator=Locator.toProperties(c.value);
						title$=locator.getProperty(Locator.LOCATOR_TITLE);
						type$=locator.getProperty(JIndexPanel.NODE_TYPE);
						nodeKey$=locator.getProperty(JIndexPanel.NODE_KEY);
						groupKey$=locator.getProperty(JIndexPanel.NODE_GROUP_KEY);
						if(emperorsKey$.equals(groupKey$)){
							sl.add(c.name);
							System.out.println("Reset:run:found member key="+nodeKey$);
							break;
						//System.out.println("Reset:run:item title="+title$+" type="+type$+" group key="+groupKey$+" node key="+nodeKey$);
						}
					}catch(Exception e){
						System.out.println("Reset:run:"+e.toString());
					}
				}
				if(sl.size()<1){
					System.out.println("Reset:run:empty emperors");
					return;
				}
				for(String s:sl)
					favorites.removeElementItem("index.jlocator", s);
				entigrator.save(favorites);
	}else
		System.out.println("Reset:run:empty Emperors");
	
}
else
	System.out.println("Reset:run:cannot find Favorites");
File report=new File(entihome$+"/"+ENTITY_KEY+"/report.txt");
if(!report.exists())
	report.createNewFile();
Date curDate = new Date();
SimpleDateFormat format = new SimpleDateFormat();
format = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
String date$= format.format(curDate);
FileOutputStream fos = new FileOutputStream(report, false);
Writer writer = new OutputStreamWriter(fos, "UTF-8");
writer.write("Report:   "+label$+"\n");
writer.write(date$+"\n");
writer.write("__________ Reset community base _____________\n");
writer.write("Cleopatra deleted, Favorites updated\n");
writer.close();
JProcedurePanel jpp=new JProcedurePanel();
String jppLocator$=jpp.getLocator();
jppLocator$=Locator.append(jppLocator$, Entigrator.ENTIHOME, entihome$);
jppLocator$=Locator.append(jppLocator$, EntityHandler.ENTITY_KEY,ENTITY_KEY);
jppLocator$=Locator.append(jppLocator$, JProcedurePanel.DIVIDER_LOCATION,String.valueOf(dividerLocation));
JConsoleHandler.execute(console, jppLocator$);
}catch(Exception e){
Logger.getLogger(getClass().getName());
}
}
}
